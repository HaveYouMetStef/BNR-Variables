import Cocoa

let numberOfStopLights: Int = 4
var population: Int
population = 5422
let townName: String = "Knowhere"
let elevation: Int
elevation = 1000
let townDescription: String = "\(townName) has a population of \(population) people, an elevation of \(elevation) feet, and \(numberOfStopLights) stop lights"
print(townDescription)
